const express = require('express');
const postController = require('./postController');
const app = express();

app.use(express.json()); 

app.get('/posts', postController.getPosts);

app.listen(3000, () => {
    console.log("server is running on port 3000")
});

