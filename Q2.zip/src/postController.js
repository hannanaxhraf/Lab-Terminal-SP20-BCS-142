const Post = require('../models/post');

exports.getPosts = async (req, res) => {
    const skip = parseInt(req.query.skip)
    const limit = parseInt(req.query.limit)
    const posts = await Post.find({}).skip(skip).limit(limit);
    return res.json(posts);
}
