const Post = require('../models/posts');

const posts = [
    {title: "Hannan", reactions: 5, userId: 66},
    {title: "Ahsan", reactions: 7, userId: 87},
];

const insertData = async () => {
    await Post.deleteMany();
    for (const post of posts) {
        const newPost = new Post(post);
        await newPost.save();
    }
    console.log("Inserted data successfully");
    process.exit();
}
insertData();
