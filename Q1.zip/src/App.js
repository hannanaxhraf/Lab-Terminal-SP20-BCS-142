import './App.css';
import Posts from './posts';

function App() {
  return (
    <div>
<Posts/>


  
    </div>
  );
}

export default App;
